[Rollercaster](rollercoaster.pdf)

- If you are a student of MATH2850J, please obey the honor code and do not clone this repository.
